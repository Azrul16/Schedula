import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_dotenv/flutter_dotenv.dart'; // Import dotenv

void main() async {
  await dotenv.load(); // Load environment variables
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Chat App',
      theme: ThemeData(
        primarySwatch: Colors.pink,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: ChatScreen(),
    );
  }
}

class ChatScreen extends StatefulWidget {
  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final List<Map<String, String>> _messages = [
    {'sender': 'User', 'text': 'Hello!'},
    {'sender': 'Bot', 'text': 'Hi, how can I help you?'},
  ];

  Future<String> getGeminiResponse(String userMessage) async {
    final String geminiAPI =
        'AIzaSyByU2HGiaQ7SG0paOMBjyxeBoN6Sph0Y3E'; // Access API key from .env file
    const String url =
        'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent';
    // Replace with the Gemini API endpoint

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $geminiAPI',
    };

    final body = json.encode({
      'message': userMessage,
      'session_id': 'unique_session_id', // Optional session ID
    });

    try {
      final response =
          await http.post(Uri.parse(url), headers: headers, body: body);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data[
            'response']; // Modify this based on the actual response format
      } else {
        return 'Error: Unable to fetch response. Status code: ${response.statusCode}';
      }
    } catch (e) {
      return 'Error: $e';
    }
  }

  void _sendMessage() async {
    if (_controller.text.isNotEmpty) {
      setState(() {
        _messages.add({
          'sender': 'User',
          'text': _controller.text,
        });
      });

      // Get the bot's response from the Gemini API
      final botResponse = await getGeminiResponse(_controller.text);

      setState(() {
        _messages.add({
          'sender': 'Bot',
          'text': botResponse,
        });
      });

      _controller.clear(); // Clear the text field
    }
  }

  Widget _buildMessageBubble(String sender, String message) {
    bool isUser = sender == 'User';
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
      child: Align(
        alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
          decoration: BoxDecoration(
            color: isUser
                ? Colors.pink[100]
                : Colors.pink[300], // Light/dark pink based on sender
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                spreadRadius: 1,
                blurRadius: 5,
              ),
            ],
          ),
          child: Text(
            message,
            style: TextStyle(
              color: isUser ? Colors.black : Colors.white,
              fontSize: 16,
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.pink,
        title: Text('Chat with Gemini',
            style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final message = _messages[index];
                return _buildMessageBubble(
                    message['sender']!, message['text']!);
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      hintText: 'Type a message...',
                      hintStyle: TextStyle(color: Colors.pink[200]),
                      filled: true,
                      fillColor: Colors.pink[50],
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    onSubmitted: (text) {
                      _sendMessage(); // Send message when "Enter" is pressed
                    },
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send, color: Colors.pink),
                  onPressed:
                      _sendMessage, // Send message when the send button is clicked
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

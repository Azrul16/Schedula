import 'package:flutter/material.dart';
// ignore: depend_on_referenced_packages
import 'package:shared_preferences/shared_preferences.dart';

class AssignmentCard extends StatefulWidget {
  final String assignmentName;
  final String courseTitle;
  final String teacherName;
  final String lastDate;

  const AssignmentCard({
    super.key,
    required this.assignmentName,
    required this.courseTitle,
    required this.teacherName,
    required this.lastDate,
  });

  @override
  State<AssignmentCard> createState() => _AssignmentCardState();
}

class _AssignmentCardState extends State<AssignmentCard> {
  late bool isCompleted = false; // Default to not completed

  @override
  void initState() {
    super.initState();
    _loadCompletionStatus(); // Load saved status from Shared Preferences
  }

  /// Load the completion status from Shared Preferences
  Future<void> _loadCompletionStatus() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      isCompleted = prefs.getBool(_generateKey()) ?? false; // Default to false
    });
  }

  /// Save the completion status to Shared Preferences
  Future<void> _saveCompletionStatus(bool status) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_generateKey(), status);
  }

  /// Generate a unique key for each assignment
  String _generateKey() {
    return 'assignment_${widget.assignmentName}_${widget.courseTitle}';
  }

  void _openBottomSheet(BuildContext context) {
    bool tempStatus = isCompleted; // Use a temporary variable for modal changes

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Mark Assignment Status",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  ListTile(
                    title: const Text("Completed"),
                    leading: Radio<bool>(
                      value: true,
                      groupValue: tempStatus,
                      onChanged: (value) {
                        setModalState(() {
                          tempStatus = value!;
                        });
                      },
                    ),
                  ),
                  ListTile(
                    title: const Text("Not Completed"),
                    leading: Radio<bool>(
                      value: false,
                      groupValue: tempStatus,
                      onChanged: (value) {
                        setModalState(() {
                          tempStatus = value!;
                        });
                      },
                    ),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () {
                      // Save the status when modal is closed
                      setState(() {
                        isCompleted = tempStatus;
                      });
                      _saveCompletionStatus(tempStatus); // Persist the state
                      Navigator.pop(context);
                    },
                    child: const Text("Save"),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _openBottomSheet(context), // Open the modal bottom sheet
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
        child: Container(
          decoration: BoxDecoration(
            color: isCompleted
                ? Colors.green
                : Colors.red, // Green if completed, red otherwise
            borderRadius: BorderRadius.circular(15),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.shade400,
                blurRadius: 8,
                offset: const Offset(4, 4),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.assignmentName,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  "Course: ${widget.courseTitle}",
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.white70,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "Teacher: ${widget.teacherName}",
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.white70,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      "Due: ${widget.lastDate}",
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
